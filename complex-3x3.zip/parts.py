class Cubie:
	def __init__(self, x, y, z):
		self.x = x
		self.y = y
		self.z = z
		self.stickers = [0, 1, 2, 3, 4, 5]
	def rotX(self):
		self.z, self.y = self.y, -self.z
		self.stickers = [
			self.stickers[1],
			self.stickers[5],
			self.stickers[2],
			self.stickers[0],
			self.stickers[4],
			self.stickers[3]
		]
	def rotY(self):
		self.x, self.z = self.z, -self.x
		self.stickers = [
			self.stickers[0],
			self.stickers[2],
			self.stickers[3],
			self.stickers[4],
			self.stickers[1],
			self.stickers[5]
		]
	def rotZ(self):
		self.x, self.y = self.y, -self.x
		self.stickers =[
			self.stickers[4],
			self.stickers[1],
			self.stickers[0],
			self.stickers[3],
			self.stickers[5],
			self.stickers[2]
		]