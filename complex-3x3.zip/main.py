import pygame, sys
from puzzle import *
pygame.init()
screen = pygame.display.set_mode((723,543))
pygame.display.set_caption("Complex 3x3 by Akeustlom")
running = True
turns, theCube = 1, Cube()
while (running):
	screen.fill((85, 85, 85))
	for event in pygame.event.get():
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_LSHIFT or event.key == pygame.K_RSHIFT:
				turns = 3
			else:
				for i in range(turns):
					if event.key == pygame.K_x:
						for cub in theCube.parts:
							cub.rotX()
					elif event.key == pygame.K_y:
						for cub in theCube.parts:
							cub.rotY()
					elif event.key == pygame.K_z:
						for cub in theCube.parts:
							cub.rotZ()
					elif event.key == pygame.K_r:
						for cub in theCube.parts:
							if cub.x == 0 or cub.x == 2:
								cub.rotX()
					elif event.key == pygame.K_l:
						for cub in theCube.parts:
							if cub.x == 0 or cub.x == -2:
								for j in range(3):
									cub.rotX()
					elif event.key == pygame.K_u:
						for cub in theCube.parts:
							if cub.y == 0 or cub.y == 2:
								cub.rotY()
					elif event.key == pygame.K_d:
						for cub in theCube.parts:
							if cub.y == 0 or cub.y == -2:
								for j in range(3):
									cub.rotY()
					elif event.key == pygame.K_f:
						for cub in theCube.parts:
							if cub.z == 0 or cub.z == -2:
								cub.rotZ()
					elif event.key == pygame.K_b:
						for cub in theCube.parts:
							if cub.z == 0 or cub.z == 2:
								for j in range(3):
									cub.rotZ()
					else:
						pass
		elif event.type == pygame.KEYUP:
			if event.key == pygame.K_LSHIFT or event.key == pygame.K_RSHIFT:
				turns = 1
	theCube.show(screen)
	pygame.display.update()
pygame.quit()
sys.exit()